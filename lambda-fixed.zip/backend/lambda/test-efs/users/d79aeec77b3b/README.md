# Welcome testuser123 to Warp Mobile AI IDE!

🔒 This is your secure workspace
🤖 AI Agent ready!
📁 Max storage: 500MB

## Getting Started
```bash
# Try these commands:
ls -la
node --version
/ai "Help me create a simple app"
/agent "Setup a React project"
```

**Happy Coding! 🚀**